# Responsive AI Agent — Experiment No. 9

React + CSS + JavaScript frontend with a FastAPI backend and Groq API.

## Project structure

- `frontend/` — React/Vite responsive chatbot UI
- `backend/` — FastAPI API; the Groq key stays on the server

## Run locally

### 1. Backend

Open a terminal in the project root:

```powershell
cd backend
python -m pip install -r requirements.txt
$env:GROQ_API_KEY="YOUR_REAL_GROQ_API_KEY"
python -m uvicorn main:app --reload --port 8000
```

For PowerShell, set the environment variable only in your local terminal. Do not commit it to GitHub.

### 2. Frontend

Open a second terminal:

```powershell
cd frontend
npm install
Copy-Item .env.example .env
npm run dev
```

Open the Vite URL shown in the terminal, usually http://localhost:5173.

The frontend reads `VITE_API_URL` from `frontend/.env`. The backend reads `GROQ_API_KEY` from the server environment.

## Input validation

The UI and backend both validate:
- whitespace-only input
- meaningful characters (letters or digits)
- maximum 100 characters

The backend validation is authoritative; frontend validation improves usability.

## Deploy for Experiment 9

Recommended beginner setup:
- Backend: Render Web Service, root directory `backend`
- Frontend: Vercel, root directory `frontend`

### Deploy backend on Render

1. Push this project to a GitHub repository.
2. In Render, create a new **Web Service** and select the repository.
3. Set **Root Directory** to `backend`.
4. Build command: `pip install -r requirements.txt`
5. Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
6. Add environment variable `GROQ_API_KEY` with your real Groq key.
7. Add `GROQ_MODEL` with `openai/gpt-oss-20b` if that model is available to your Groq account.
8. After deployment, copy the backend URL, for example `https://your-api.onrender.com`.

### Configure CORS for production

In the Render backend environment variables, set:
- `FRONTEND_ORIGIN` = your deployed Vercel URL, e.g. `https://your-ai-agent.vercel.app`

The backend currently permits localhost for development and the exact `FRONTEND_ORIGIN` set in deployment.

### Deploy frontend on Vercel

1. Import the same GitHub repository into Vercel.
2. Set **Root Directory** to `frontend`.
3. Framework preset: Vite.
4. Add environment variable:
   - `VITE_API_URL` = your deployed Render backend URL, without a trailing slash.
5. Deploy the frontend.

If you update environment variables, redeploy the frontend. If you change `FRONTEND_ORIGIN`, redeploy/restart the backend.

## Before submitting

- Test the live website on a phone and desktop.
- Ask `What is Python?` and confirm a response appears.
- Test `???!!!` and an input longer than 100 characters.
- Keep the Groq key only in Render's environment variables. Never put it in React code or GitHub.
- Save screenshots of the GitHub repository, deployment dashboard, live URL, and working AI response.

## Troubleshooting

- `Failed to fetch`: verify `VITE_API_URL`, backend status, and CORS `FRONTEND_ORIGIN`.
- `AI service is not configured`: add `GROQ_API_KEY` to Render environment variables.
- Model not found: choose a model currently available in your Groq account and update `GROQ_MODEL`.
- 429/rate limit: wait and try again later.
